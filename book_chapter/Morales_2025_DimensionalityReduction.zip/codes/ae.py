import numpy as np                                          # array operations
import torch                                                # deep learning library
import torch.nn as nn                                       # neural network operations
import torch.optim as optim                                 # neural network optimizer
import torch.nn.functional as F                             # functional layers
from torch.utils.data import DataLoader, TensorDataset      # tensor data opeartions
from torch.utils.data importt random_split                  # random train-test split
from sklearn.preprocessing import MinMaxScaler              # data preprocessing

df_perm = np.load('data/data_500_128x128.npy')              # (500, 128, 128)
df_perm_f = np.reshape(df_perm, (df_perm.shape[0], -1))     # (500, 16384)

class AutoEncoder(nn.Module):                               # AutoEncoder architecture class
    def __init__(self, layers=[4, 16, 64]):                 # size of 3 hidden layers
        super(AutoEncoder, self).__init__()
        self.encoder = nn.Sequential(                       # ENCODER
            self.conv_block(1, layers[0]),                  # first encoding layer
            self.conv_block(layers[0], layers[1]),          # second encoding layer
            self.conv_block(layers[1], layers[2]),          # third encoding layer
        )
        self.decoder = nn.Sequential(                       # DECODER
            self.deconv_block(layers[2], layers[1]),        # first decoding layer
            self.deconv_block(layers[1], layers[0]),        # second decoding layer
            self.deconv_block(layers[0], 1),                # third decoding layer
        )

    def conv_block(self, ic, oc):                           # architecture of encoding layer
        return nn.Sequential(
            nn.Conv2d(ic, oc, kernel_size=3, padding=1),    # convoluation
            nn.BatchNorm2d(out_channels),                   # batch normalization
            nn.ReLU(),                                      # activation
            nn.MaxPool2d(kernel_size=2, stride=2)           # pooling
        )
    
    def deconv_block(self, ic, oc):                         # architecture of decoding layer
        return nn.Sequential(
            nn.Upsample(scale_factor=2),                    # upsampling
            nn.Conv2d(ic, oc, kernel_size=3, padding=1),    # convolution
            nn.BatchNorm2d(oc),                             # batch normalization
            nn.ReLU()                                       # activation
        )
    
    def forward(self, x):                                   # AutoEncoder 
        z = self.encoder(x)                                 # Encoder
        y = self.decoder(z)                                 # Decoder
        return y
    

scaler = MinMaxScaler()                                             # initialize data scaler
scaler.fit(df_perm_f)                                               # fit data scaler
XX = scaler.transform(df_perm_f).reshape(df_perm.shape)             # normalize data
X_dataset = torch.tensor(np.expand_dims(XX,1), dtype=torch.float32) # tensor dataset
X_train, X_valid = random_split(X_dataset, [450, 50])               # train-valid split
trainloader = DataLoader(X_train, batch_size=16, shuffle=True)      # training data loader
validloader = DataLoader(X_valid, batch_size=16, shuffle=False)     # validation data loader

device = torch.device("cuda" if torch.cuda.is_available() else "cpu") # use GPU for training
model = AutoEncoder(layers=[16, 64, 256]).to(device)                  # initialize NN
optimizer = optim.Adam(params=model.parameters(), lr=1e-3)            # initialize optimizer
criterion = nn.MSELoss().to(device)                                   # initialize loss

epochs = 200                                        # define number of training epochs
train_loss, valid_loss = [], []                     # initialize train and valid losses
for epoch in range(epochs):                         # begin training loop
    # training                              
    epoch_train_loss = []                           # reset epoch loss - train
    for i, x in enumerate(trainloader):             
        x = x.to(device)                            # send batch to GPU
        optimizer.zero_grad()                       # reset gradients
        y = model(x)                                # forward pass
        loss = criterion(y, x)                      # calculate loss
        loss.backward()                             # backward pass
        optimizer.step()                            # calculate gradients
        epoch_train_loss.append(loss.item())        # append epoch loss
    train_loss.append(np.mean(epoch_train_loss))    # appen total loss
    # validation
    model.eval()                                    # freeze model
    epoch_valid_loss = []                           # reset epoch loss - valid
    with torch.no_grad():
        for i, x in enumerate(validloader):         
            x = x.to(device)                        # send batch to GPU
            y = model(x)                            # forward pass
            loss = criterion(y, x)                  # calculate loss
            epoch_valid_loss.append(loss.item())    # append epoch loss
    valid_loss.append(np.mean(epoch_valid_loss))    # append total loss

# Obtain final predictions for dataset and back-normalize
pred = model(X_dataset.to(device)).cpu().detach().numpy().squeeze()
xhat = scaler.inverse_transform(pred.reshape(df_perm_f.shape)).reshape(df_perm.shape)