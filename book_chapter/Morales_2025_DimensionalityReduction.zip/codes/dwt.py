import numpy as np                                          # array operations
from pywt import wavedec2, waverec2                         # DWT operations
from pywt import coeffs_to_array, array_to_coeffs           # DWT coefficients-to-arrays
from skimage.metrics import structural_similarity           # reconstruction metrics
from skimage.metrics import peak_signal_noise_ratio         # reconstruction metrics
from skimage.metrics import mean_squared_error              # reconstruction metrics

df_perm = np.load('data/data_500_128x128.npy')              # (500, 128, 128)

keep_percs = np.linspace(0.01, 0.99, 100)                   # energy cutoffs
wavelet = 'haar'                                            # generating wavelet
levels = 1                                                  # decomposition level

reconstructions = {'xhat':[], 'coeffs':[]}
for i, k in enumerate(keep_percs):
    c = wavedec2(df_perm, wavelet=wavelet, level=levels)    # DWT coefficients
    c_arr, c_slices = coeffs_to_array(c)                    # coefficients-to-array
    c_sort = np.sort(np.abs(c_arr.reshape(-1)))             # sort by magnitude

    threshold = c_sort[int(np.floor((1-k)*len(c_sort)))]    # cutoff indices
    c_arr_t = c_arr * (np.abs(c_arr) > threshold)           # truncate coefficients
    c_t = array_to_coeffs(c_arr_t, c_slices)                # array-to-coefficients
    recs = waverec2(c_t, wavelet=wavelet)                   # reconstructed images
    
    reconstructions['xhat'].append(recs)                    # store reconstructions
    reconstructions['coeffs'].append(c_arr)                 # store coefficients