import numpy as np                                              # array operations
from sklearn.decomposition import DictionaryLearning            # dictionary learning
from sklearn.decomposition import SparseCoder                   # sparse coding

df_perm = np.load('data/data_500_128x128.npy')                  # (500, 128, 128)
df_perm_f = np.reshape(df_perm, (df_perm.shape[0], -1))         # (500, 16384)

n_atoms = 500                                                   # atoms in dictionary
dl = DictionaryLearning(n_components=n_atoms)                   # initialize dictionray
dictionary = dl.fit(df_perm_f)                                  # fit to data matrix
atoms = dictionary.components_                                  # extract atoms

sparse_code = SparseCoder(atoms).fit_transform(df_perm_f)       # train sparse coder
sparse_recs = np.reshape(sparse_code @ atoms, df_perm_f.shape)  # reconstructed images